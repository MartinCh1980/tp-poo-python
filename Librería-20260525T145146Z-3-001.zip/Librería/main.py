def mostrarMenu():
    print('0 Salir')
    print('1 - Agregar libro')
    print('2 - Agregar miembro')
    print('3 - Mostrar libros')
    print('4 - Mostrar miembros')
    print('5 - Prestar libros')
    print('6 - Devolver libros')
    print('7 - Consultar estado libros')
    print('8 - Consultar libro miembros')

while True:
    mostrarMenu()
    opcion = input('Seleccione una opción: ')
    if opcion == '1':
        biblioteca1.agregarLibros(libro1)
    elif opcion == '2':
        biblioteca1.agregarMiembro(miembro1)
    elif opcion == '3':
        biblioteca1.mostrarLibros()
    elif opcion == '4':
        biblioteca1.mostrarMiembros()