class Libro:
    def __init__(self, titulo, autor, isbn, estado):
        self.__titulo = titulo
        self.__autor = autor
        self.__isbn = isbn
        self.__estado = estado

    def getTitulo(self):
        return self.__titulo
    
    def getAutor(self):
        return self.__autor
    
    def getIsbn(self):
        return self.__isbn
    
    def getEstado(self):
        return self.__estado
    
    def setEstado(self, estado):
        self.__estado = estado




libro1 = Libro('Programación','Ema', 1234, 'Disponible')
libro2 = Libro('Etica','Manu', 1235, 'Disponible')
libro3 = Libro('DB','Nico', 1235, 'Disponible')
miembro1 = Miembro('45639678','Antony')
biblioteca1 = Biblioteca()



