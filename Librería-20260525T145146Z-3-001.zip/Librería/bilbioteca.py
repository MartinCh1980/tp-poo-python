from libro import Libro
from miembro import Miembro


class Biblioteca:
    def __init__(self):
        self.__libros = []
        self.__miembros = []

    def agregarMiembro(self, miembro):
        self.__miembros.append(miembro)

    def agregarLibros(self, libro):
        self.__libros.append(libro)

    def buscarLibro(self, isbn):
        pass
    def mostrarLibro(self, isbn, miembro):
        # terminar esta función-----------------------------------------
        for libro in self.__libros:
            if libro.getEstado():
            print(f"Título: {libro.getTitulo()} | Autor: {libro.getAutor()} | ISBN: {libro.getIsbn()} | Estado: {libro.getEstado()}") 
    
    def mostrarMiembros(self):
        for miembro in self.__miembros:
            print(f"Nombre: {miembro.getNombre()} | Dni: {miembro.getDni()}")

    def prestarLibro(self):
        pass
    
    def devolucionLibros(self):
        pass