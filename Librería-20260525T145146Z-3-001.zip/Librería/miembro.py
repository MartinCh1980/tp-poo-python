class Miembro:
    def __init__(self, dni, nombre):
        self.__dni = dni
        self.__nombre = nombre

    def getNombre(self):
        return self.__nombre
    
    def getDni(self):
        return self.__dni